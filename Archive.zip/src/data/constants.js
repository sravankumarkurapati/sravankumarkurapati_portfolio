export const Bio = {
  name: "Sravan Kumar",
  roles: [
    "Full Stack Developer",
  "Software Engineer",
  "Backend Developer", 
  "Java Developer",
  ],
 description: "A passionate developer with expertise in Java, Spring Boot, React, and enterprise technologies. Currently pursuing a Master's in Information Systems at Northeastern University with a 4.0 GPA.",
 github: "https://github.com/rishavchanda",
  resume:
    "https://docs.google.com/document/d/1JFM_w9gG_KFWS102STYHIYaud1QzwowgotkYlyzBRlk/edit?tab=t.0",
  linkedin: "https://www.linkedin.com/in/sravankumar-kurapati/",
  twitter: "",
 
};

export const skills = [
  {
    title: "Frontend",
    skills: [
      {
        name: "React Js",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg",
      },
      {
        name: "Angular",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/angularjs/angularjs-original.svg",
      },
      {
        name: "Redux",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/redux/redux-original.svg",
      },
      {
        name: "TypeScript",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-original.svg",
      },
      {
        name: "JavaScript",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg",
      },
      {
        name: "HTML",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg",
      },
      {
        name: "CSS",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg",
      },
      {
        name: "Bootstrap",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/bootstrap/bootstrap-original.svg",
      }
    ],
  },
  {
    title: "Backend & Frameworks",
    skills: [
      {
        name: "Java",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg",
      },
      {
        name: "Spring Boot",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/spring/spring-original.svg"
      },
      {
        name: "Spring Security", 
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/spring/spring-original.svg"
      },
      {
        name: "Spring Cloud",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/spring/spring-original.svg"
      },
      {
        name: "Hibernate",
        image: "https://img.icons8.com/color/48/000000/hibernate.png"
      },
      {
        name: "Node.js",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/nodejs/nodejs-original.svg",
      },
      {
        name: "Express.js",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/express/express-original.svg",
      },
      {
        name: "REST APIs",
        image: "https://img.icons8.com/dusk/64/000000/api.png"
      }
    ],
  },
  {
    title: "Databases",
    skills: [
      {
        name: "Oracle",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/oracle/oracle-original.svg"
      },
      {
        name: "MongoDB",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/mongodb/mongodb-original.svg",
      },
      {
        name: "Couchbase", 
        image: "https://img.icons8.com/color/48/000000/database.png"
      },
      {
        name: "MySQL",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original.svg",
      }
    ],
  },
  {
    title: "Enterprise & Cloud",
    skills: [
      {
        name: "OpenShift",
        image: "https://img.icons8.com/color/48/000000/openshift.png"
      },
      {
        name: "WebLogic",
        image: "https://img.icons8.com/color/48/000000/oracle-logo.png"
      },
      {
        name: "Kafka",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/apachekafka/apachekafka-original.svg"
      },
      {
        name: "ServiceNow", 
        image: "https://img.icons8.com/color/48/000000/service.png"
      },
      {
        name: "Microservices",
        image: "https://img.icons8.com/color/48/000000/api-settings.png"
      }
    ],
  },
  {
    title: "Development Tools",
    skills: [
      {
        name: "Git",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/git/git-original.svg",
      },
      {
        name: "GitHub",
        image: "https://img.icons8.com/fluency/48/000000/github.png",
      },
      {
        name: "VS Code",
        image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/vscode/vscode-original.svg",
      },
      {
        name: "NetBeans",
        image: "https://img.icons8.com/color/48/000000/netbeans.png",
      },
      {
        name: "Postman",
        image: "https://img.icons8.com/dusk/64/000000/postman-api.png",
      },
      {
        name: "Maven",
        image: "https://img.icons8.com/color/48/000000/maven-ios.png",
      },
      {
        name: "JWT",
        image: "https://img.icons8.com/color/48/000000/java-web-token.png",
      },
      {
        name: "Swagger",
        image: "https://img.icons8.com/color/48/000000/api.png",
      }
    ],
  }
];

export const experiences = [
  {
    id: 0,
    img: "https://cdn.worldvectorlogo.com/logos/northeastern-university.svg",
    role: "Senior Technical Program Assistant",
    company: "NU Student Temps, Northeastern University",
    date: "Oct 2025 - Present",
    desc: "Lead development and optimization of advanced recruitment automation systems, mentoring junior team members on technical implementation strategies. Architect scalable software solutions and system integrations to enhance cross-platform data synchronization between student information systems and recruitment workflows. Spearhead process improvement initiatives that resulted in 40% reduction in time-to-hire and improved operational efficiency across student employment operations. Design and implement comprehensive analytics dashboards and reporting tools for senior management, providing strategic insights on recruitment trends and performance metrics. Manage technical project roadmaps and coordinate with multiple stakeholders to deliver enterprise-level solutions for student employment operations.",
    skills: [
      "Java",
      "React.js",
      "System Architecture",
      "Process Improvement",
      "Analytics Dashboards",
      "Project Management",
      "Team Leadership"
    ],
    doc: "https://img.icons8.com/color/48/000000/certificate.png",
  },
  {
    id: 1,
    img: "https://cdn.worldvectorlogo.com/logos/northeastern-university.svg",
    role: "Technical Program Assistant",
    company: "NU Student Temps, Northeastern University",
    date: "Sep 2021 - Oct 2025",
    desc: "Developed automated web applications using Java and React.js to group student talent pools and streamline recruitment workflows, improving efficiency and matching candidates with the right technical interviewers. Designed dashboards and structured workflows to optimize technical interview assignments, increasing recruiting efficiency by 25% within 5 months. Worked closely with the Student Employment Office, tracking issues, identifying process improvement opportunities, and providing innovative solutions. Contributed to enhancing social media engagement and brand identity by providing design inputs, including logo creation, and collaborating effectively with the team.",
    skills: [
      "Java",
      "React.js",
      "JavaScript",
      "Dashboard Design",
      "Process Improvement",
      "Team Collaboration",
      "Web Applications"
    ],
    doc: "https://img.icons8.com/color/48/000000/certificate.png",
  },
  {
    id: 2,
    img: "https://cdn.worldvectorlogo.com/logos/tata-consultancy-services.svg",
    role: "Senior Software Engineer",
    company: "Tata Consultancy Services",
    date: "Jan 2021 - Dec 2024",
    desc: "Developed scalable REST-based applications using Java, Spring Boot, and Angular for mobile transactions and enterprise collections systems, improving performance 27x and reliability. Modernized legacy batch processes with multithreading, reducing execution time by 50%. Automated recurring workflows, rating configurations, and reminder communications, saving $2M + $1.2M + $40K annually and reducing manual effort. Reduced monthly open tickets from 100+ to 20 by identifying recurring issues and implementing long-term system improvements. Designed and implemented front-end and back-end features, including microservices and APIs, contributing to enterprise digital transformation initiatives. Transitioned development projects to a DevOps model, generating additional revenue of €1M.",
    skills: [
      "Java",
      "Spring Boot",
      "Angular",
      "REST APIs",
      "Microservices",
      "Oracle",
      "Multithreading",
      "DevOps"
    ],
    doc: "https://img.icons8.com/color/48/000000/certificate.png",
  }
];

export const education = [
  {
    id: 0,
    img: "https://cdn.worldvectorlogo.com/logos/northeastern-university.svg",
    school: "Northeastern University",
    date: "Expected May 2027",
    grade: "4.0 GPA",
    desc: "Currently pursuing a Master of Science in Information Systems with a perfect 4.0 GPA. Focusing on advanced software development, enterprise systems, data analytics, and information technology management. Actively engaged in hands-on technical projects while working as a Senior Technical Program Assistant, applying classroom knowledge to real-world software solutions.",
    degree: "Master of Science in Information Systems",
  },
  {
    id: 1,
    img: "https://img.icons8.com/color/48/000000/university.png",
    school: "BV Raju Institute of Technology, JNTU Hyderabad",
    date: "Apr 2011",
    grade: "Bachelor's Degree",
    desc: "Completed Bachelor of Technology in Computer Science from Jawaharlal Nehru Technological University Hyderabad. Built a strong foundation in programming fundamentals, data structures, algorithms, software engineering principles, and computer science theory. This education provided the technical groundwork for my successful career progression in enterprise software development.",
    degree: "Bachelor of Technology - Computer Science",
  }
];

export const projects = [
  {
    id: 11,
    title: "DecisionHub",
    date: "Jan 2024 - Dec 2023",
    description:
      "A Rule Builder application “Decision Hub” that empowers Business Analysts to create, save, and visualize decision strategies. Provide a no-code rule writing experience and visual representation to test these rules in real-time and observe the calculations at each step.",
    image:
      "https://github.com/rishavchanda/DecisionHub/raw/master/assets/testRule.jpg",
    tags: [
      "React Js",
      "PostgressSQL",
      "Node Js",
      "Express Js",
      "Redux",
      "React Flow",
    ],
    category: "web app",
    github: "https://github.com/rishavchanda/DecisionHub",
    webapp: "https://decisionhub.netlify.app/",
  },
  {
    id: 9,
    title: "Trackify",
    date: "Jun 2023 - Jul 2023",
    description:
      "Trackify is a web application designed to streamline task management and enhance productivity in the workplace. It provides a user-friendly interface for employers to keep track of their employees' daily work activities and empowers employees to log their tasks efficiently. \nAdmin Credentials: # Email: testadmin@gmail.com #Password- 123@testadmin, Employee Credentials:	#Email: testemployee@gmail.com	#Password- 123@Testemployee",
    image:
      "https://user-images.githubusercontent.com/64485885/255202416-e1f89b04-2788-45b0-abc2-9dec616669e2.png",
    tags: [
      "Docker",
      "AWS",
      "DuckDNS",
      "Eslint",
      "Husky",
      "CI/CD",
      "React Js",
      "MongoDb",
      "Node Js",
      "Express Js",
      "Redux",
    ],
    category: "web app",
    github: "https://github.com/rishavchanda/Trackify",
    webapp: "https://trackify-management.netlify.app/",
  },
  {
    id: 0,
    title: "Podstream",
    date: "Apr 2023 - May 2023",
    description:
      "Developed a full-stack web application that allows users to search for, play, and pause their favorite podcasts on demand and create podcasts. Implemented user authentication using Google Auth and Jwt Auth, made responsive user interface with React JS that provides users with a seamless experience across all devices. Practiced agile methodologies to optimize team efficiency and communication.",
    image:
      "https://user-images.githubusercontent.com/64485885/234602896-a1bd8bcc-b72b-4821-83d6-8ad885bf435e.png",
    tags: ["React Js", "MongoDb", "Node Js", "Express Js", "Redux"],
    category: "web app",
    github: "https://github.com/rishavchanda/Podstream",
    webapp: "https://podstream.netlify.app/",
    member: [
      {
        name: "Rishav Chanda",
        img: "https://avatars.githubusercontent.com/u/64485885?v=4",
        linkedin: "https://www.linkedin.com/in/rishav-chanda-b89a791b3/",
        github: "https://github.com/rishavchanda/",
      },
      {
        name: "Upasana Chaudhuri",
        img: "https://avatars.githubusercontent.com/u/100614635?v=4",
        linkedin: "https://www.linkedin.com/in/upasana-chaudhuri-2a2bb5231/",
        github: "https://github.com/upasana0710",
      },
    ],
  },
  {
    id: 1,
    title: "Vexa",
    date: "Oct 2022 - Jan 2023",
    description:
      "Designed and developed the Vexa project, a project management app that helps users and teams stay organized and on track. Implemented key features such as task tracking, team collaboration, and time tracking to improve productivity and project outcomes and also invite team/project members. The plan is to add a community of users where they can find developers and other team members and chat system implementation.",
    image:
      "https://user-images.githubusercontent.com/64485885/234916413-96296f13-fe4b-4cc4-b215-e72bd7c27928.png",
    tags: [
      "React Js",
      "MongoDb",
      "Node Js",
      "Express Js",
      "Redux",
      "NodeMailer",
    ],
    category: "web app",
    github: "https://github.com/rishavchanda/Project-Management-App",
    webapp: "https://vexa-app.netlify.app/",
  },
  {
    id: 2,
    title: "Brain Tumor Detection",
    date: "Jan 2023 - Mar 2023",
    description:
      "Preprocessed and augmented the dataset to improve model accuracy, trained the model, created API using model and Python, and used React web app for the project's front end. Achievements: Achieved an accuracy of 99.2% to accurately detect brain tumors from medical images.",
    image:
      "https://github.com/rishavchanda/Brain-Tumor-Detection/raw/main/Readme_resource/Image2.png",
    tags: ["Python", "Keras", "TensorFlow", "VGG16", "Pickle", "React"],
    category: "machine learning",
    github: "https://github.com/rishavchanda/Brain-Tumor-Detection",
    webapp: "https://brain-tumor.netlify.app/",
    member: [
      {
        name: "Rishav Chanda",
        img: "https://avatars.githubusercontent.com/u/64485885?v=4",
        linkedin: "https://www.linkedin.com/in/rishav-chanda-b89a791b3/",
        github: "https://github.com/rishavchanda/",
      },
      {
        name: "Upasana Chaudhuri",
        img: "https://avatars.githubusercontent.com/u/100614635?v=4",
        linkedin: "https://www.linkedin.com/in/upasana-chaudhuri-2a2bb5231/",
        github: "https://github.com/upasana0710",
      },
    ],
  },
  {
    id: 3,
    title: "Buckoid",
    date: "Dec 2021 - Apr 2022",
    description:
      "App Is Currently In Playstore 100+ Downloads. This Project proposes an “Expense Tracking App”. Keep track of your personal expenses and compare them to your monthly income with the budget planner. It has Google Drive Cloud API for Backup of User Room Database. Made with Kotlin in MVVM Architecture & Live Data.",
    image:
      "https://camo.githubusercontent.com/3ad28aa710d18525f1fc87de056ed53c706d09979589bfd5a773df36653bad38/68747470733a2f2f666972656261736573746f726167652e676f6f676c65617069732e636f6d2f76302f622f6c6f67696e2d65613565322e61707073706f742e636f6d2f6f2f4255434b4f49442532302831292e706e673f616c743d6d6564696126746f6b656e3d32653735376235372d323964372d346263612d613562322d653164346538313432373435",
    tags: ["Kotlin", "MVVM", "Room Database", "Google Drive Cloud API"],
    category: "android app",
    github: "https://github.com/rishavchanda/Buckoid-Android-App",
    webapp: "https://play.google.com/store/apps/details?id=com.rishav.buckoid",
  },
  {
    id: 10,
    title: "Job Finding App",
    date: "Jun 2023 - Jul 2023",
    description:
      "A Job Finding App made with React Native, Axios. Users can search for any job coming from API and apply there.",
    image:
      "https://user-images.githubusercontent.com/64485885/255237090-cf798a2c-1b41-4bb7-b904-b5353a1f08e8.png",
    tags: ["React Native", "JavaScript", "Axios"],
    category: "android app",
    github: "https://github.com/rishavchanda/Job-finder-App",
    webapp: "https://github.com/rishavchanda/Job-finder-App",
  },
  {
    id: 4,
    title: "Whatsapp Clone",
    date: "Jul 2021",
    description:
      "A WhatsApp clone made with React JS, Firebase, and Material UI. It has Phone Authentication, Real-time Database. It has a chat room where users can chat with each other. It has a sidebar where users can see all the chat rooms and can create a new chat room. It has a login page where users can log in with their Google account.",
    image:
      "https://firebasestorage.googleapis.com/v0/b/whatsapp-clone-rishav.appspot.com/o/Screenshot%20(151).png?alt=media&token=48391593-1ef0-4a8c-a92a-eb82bdf38e89",
    tags: ["React Js", "Firebase", "Firestore", "Node JS"],
    category: "web app",
    github: "https://github.com/rishavchanda/Whatsapp-Clone-React-Js",
    webapp: "https://whatsapp-clone-rishav.web.app",
  },
  {
    id: 5,
    title: "Todo Web App",
    date: "Jun 2021",
    description:
      " A Todo Web App made with React JS, Redux, and Material UI. It has a login page where users can log in with their Google account. It has a sidebar where users can see all the tasks and can create a new task. It has a calendar where users can see all the tasks on a particular date. It has a search bar where users can search for a particular task.",
    image:
      "https://camo.githubusercontent.com/84ac6ab6f378348ef28d8184062b7e9e3511a1252ae3966eaa49e8e998f732a7/68747470733a2f2f666972656261736573746f726167652e676f6f676c65617069732e636f6d2f76302f622f746f646f2d6170702d63386331392e61707073706f742e636f6d2f6f2f53637265656e73686f74253230283938292e706e673f616c743d6d6564696126746f6b656e3d33643335646366322d626666322d343730382d393031632d343232383866383332386633",
    tags: ["React Js", "Local Storage", "AWS Auth", "Node JS"],
    category: "web app",
    github: "https://github.com/rishavchanda/Todo-Web-App",
    webapp: "https://rishav-react-todo.netlify.app/",
  },
  {
    id: 6,
    title: "Breaking Bad",
    date: "Jun 2021",
    description:
      "A simple react app that shows the characters of the famous TV series Breaking Bad. It uses the Breaking Bad API to fetch the data. It also has a search bar to search for a particular character.",
    image:
      "https://camo.githubusercontent.com/937774368308a82419f53dd6eeb4a8675780e119636488b4e3cfe5d34859a72a/68747470733a2f2f666972656261736573746f726167652e676f6f676c65617069732e636f6d2f76302f622f746f646f2d6170702d63386331392e61707073706f742e636f6d2f6f2f53637265656e73686f7425323028313534292e706e673f616c743d6d6564696126746f6b656e3d65613439383630632d303435362d343333342d616435372d336239346663303333363263",
    tags: ["React Js", "API", "Axios", "Node JS"],
    category: "web app",
    github: "https://github.com/rishavchanda/Breaking-Bad",
    webapp: "https://breaking-bad-webapp.netlify.app",
  },
  {
    id: 7,
    title: "Quiz App",
    date: "Dec 2020 - Jan 2021",
    description:
      "A android quiz app made with Java and Firebase. It has a login page where users can log in with their Google account. It has a sidebar where users can see all the quiz categories and can create a new quiz. It has a leaderboard where users can see the top 10 scorers. It has a search bar where users can search for a particular quiz.",
    image:
      "https://github-production-user-asset-6210df.s3.amazonaws.com/64485885/239726262-c1b061d1-d9d0-42ef-9f1c-0412d14bc4f6.gif",
    tags: ["Java", "Android Studio", "Firebase", "Google Auth"],
    category: "android app",
    github: "https://github.com/rishavchanda/Quiz-Earn",
    webapp: "https://github.com/rishavchanda/Quiz-Earn",
  },
  {
    id: 8,
    title: "Face Recognition",
    date: "Jan 2021",
    description:
      "A Face recognition python app made with OpenCV. It uses face_recognition library to detect faces. It uses the webcam to detect faces. It also has a search bar to search for a particular face.",
    image:
      "https://dontrepeatyourself.org/media/face-recognition-with-python-dlib-and-deep-learning_cezKZBj.png",
    tags: ["Python", "Keras", "TensorFlow", "VGG16", "Pickle", "React"],
    category: "machine learning",
    github: "https://github.com/rishavchanda/Face-Recodnition-AI-with-Python",
    webapp: "https://github.com/rishavchanda/Face-Recodnition-AI-with-Python",
  },
];

